import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from './auth/auth.service';
import { Plugins } from '@capacitor/core';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent implements OnInit,OnDestroy{
  private authSub:Subscription;
  private previousAuthState:boolean=false;
  constructor(
    private authService:AuthService,
    private router:Router
    ) {}
  ngOnDestroy(){
    if(this.authSub)
    {
      this.authSub.unsubscribe();
    }
  }
  ngOnInit(){
    this.authSub=this.authService.userIsAuthenticated.subscribe(isAuth => {
      if(!isAuth && this.previousAuthState!==isAuth )
        this.router.navigateByUrl('/auth');
      this.previousAuthState=isAuth;

    })
  }
  onLogout()
  {
    this.authService.logout()

  }
}
