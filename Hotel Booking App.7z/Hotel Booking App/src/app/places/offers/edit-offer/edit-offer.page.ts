import { error } from '@angular/compiler/src/util';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AlertController, LoadingController, NavController } from '@ionic/angular';
import { Subscription } from 'rxjs';
import { Place } from '../../place.model';
import { PlacesService } from '../../places.service';

@Component({
  selector: 'app-edit-offer',
  templateUrl: './edit-offer.page.html',
  styleUrls: ['./edit-offer.page.scss'],
})
export class EditOfferPage implements OnInit,OnDestroy {
  place:Place;
  form:FormGroup;
  isLoading:boolean;
  placeId:string;
  private placeSub:Subscription
  constructor(
    private route:ActivatedRoute,
    private navController:NavController,
    private placesService:PlacesService,
    private router:Router,
    private loadingController:LoadingController,
    private alertController:AlertController
  ) { }

  ngOnDestroy(){
    if(this.placeSub)
    {
      this.placeSub.unsubscribe();
    }
  }
  ngOnInit() {
    this.route.paramMap.subscribe(paramMap => {
      if (!paramMap.has('placeId')) {
        this.navController.navigateBack('/places/tabs/offers');
        return;
      }
    this.placeId=paramMap.get('placeId')
    this.isLoading=true;
    this.placeSub=this.placesService
    .getPlace(paramMap.get('placeId'))
    .subscribe(place =>{
      console.log("places list got from getPlaces :-> ",place)
      this.place=place;
      this.form=new FormGroup({
        title:new FormControl(this.place.title,{
          updateOn:'blur',
          validators:[Validators.required]
        }),
        description:new FormControl(this.place.description,{
          updateOn:'blur',
          validators:[Validators.required,Validators.maxLength(100)]
        })
      });
      this.isLoading=false;
     },
     error => {
       this.alertController.create({
         header:'An error has occured',
         message:'Place could not be fetched',
         buttons:[{text:'Okay' ,handler:() => {
           this.router.navigate(['/places/tabs/offers']);
         }

         }]
       }).then(alertElement => {
         alertElement.present();
       })
     }
     )


    });
  }
  onUpdateOffer()
  {
    if(!this.form.valid)
    {
      return;
    }
    else{
      this.loadingController.create({
        message:'Updating Place...'
      }).then(loadingElement => {
        loadingElement.present();
        this.placesService.updateOffer(
          this.place.id,
          this.form.value.title,
          this.form.value.description
        ).subscribe(() => {
          loadingElement.dismiss();
          this.form.reset();
          this.router.navigate(['/places/tabs/offers']);
        });
      }

      )
      console.log(this.form);

    }
  }

}
