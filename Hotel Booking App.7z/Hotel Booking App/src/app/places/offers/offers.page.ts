import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { IonItemSliding } from '@ionic/angular';
import { Subscription } from 'rxjs';
import { Place } from '../place.model';
import { PlacesService } from '../places.service';

@Component({
  selector: 'app-offers',
  templateUrl: './offers.page.html',
  styleUrls: ['./offers.page.scss'],
})
export class OffersPage implements OnInit,OnDestroy {
  offers:Place[];
  isLoading:boolean;

  private placesSub:Subscription
  constructor(private placesService:PlacesService,private router:Router) { }
  ngOnDestroy() {
   if(this.placesSub)
   {
     this.placesSub.unsubscribe();
   }
  }

  ngOnInit() {
    console.log("Log initialized of Offers.page.ts")
    this.placesSub=this.placesService.places.subscribe(places => {
      this.offers=places;
    })
  }
  ionViewWillEnter()
  {
    this.isLoading=true;
    this.placesService.fetchPlaces().subscribe(() => {
      this.isLoading=false;
    });
  }
  public onEdit(offerId:string,slidingItem:IonItemSliding) {

    this.router.navigate(['/','places','tabs','offers','edit',offerId]);
    slidingItem.close();

    console.log('Editing item'+offerId);
  }
}
