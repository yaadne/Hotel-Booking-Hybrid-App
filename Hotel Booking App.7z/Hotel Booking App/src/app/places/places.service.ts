import { HttpClient} from '@angular/common/http';
import { Injectable } from '@angular/core';

import { BehaviorSubject, of } from 'rxjs';
import {take,map, tap, switchMap} from 'rxjs/operators'
import { AuthService } from '../auth/auth.service';
import {Place} from './place.model'


// new Place(
//   'p1',
//   'Pune shanivar wada',
//   'Pune is Maharashtras second largest city',
//   'https://upload.wikimedia.org/wikipedia/commons/b/b5/Shaniwarwada_gate.JPG',
//   2000,
//   new Date('2019-01-01'),
//   new Date('2020-10-01'),
//   'abc'
//   ),
//   new Place(
//     'p2',
//     'Mumbai',
//     'Mumbai is the financial capital city of India',
//     'https://upload.wikimedia.org/wikipedia/commons/thumb/1/14/Mumbai_Skyline_at_Night.jpg/300px-Mumbai_Skyline_at_Night.jpg',
//     5000,
//     new Date('2021-01-01'),
//     new Date('2021-10-01'),
//     'abc'
//     ),
//   new Place(
//     'p3',
//      'Banglore',
//       'Banglore  is the IT capital of India',
//       'https://upload.wikimedia.org/wikipedia/commons/thumb/2/23/UB_City_at_night_.jpg/250px-UB_City_at_night_.jpg',
//       3000,
//       new Date('2021-01-01'),
//       new Date('2021-10-01'),
//       'abc'
//       )

interface PlaceData
{
  availableFrom: string;
  availableTo: string;
  description: string;
  imageUrl:string;
  price: number;
  title: string;
  userId: string;
}
@Injectable({
  providedIn: 'root'
})
export class PlacesService
{

  private _places=new BehaviorSubject<Place[]>([]);


  get places()
  {
    return this._places.asObservable();
  }

  constructor(
    private authService:AuthService,
    private http:HttpClient
   ) { }


   fetchPlaces()
   {
     return this.http.get<{[key :string]:PlaceData}>('')
     .pipe
     (
       map(responseData => {
         const places=[];
         for(const key in responseData)
         {
           if(responseData.hasOwnProperty(key))
           {
             places.push(new Place(
               key,
               responseData[key].title,
               responseData[key].description,
               responseData[key].imageUrl,
               responseData[key].price,
               new Date(responseData[key].availableFrom),
               new Date(responseData[key].availableTo),
               responseData[key].userId
               ));
           }
         }
         return places;
       }),
       tap(places => {
         this._places.next(places);
       })
     )
    }

  getPlace(id: string)
  {
    console.log("In getPlace()")
    return this.http.get<PlaceData>(
      ``
    ).pipe(
      map(placeData => {
        console.log("After loading from server",placeData);
        return new Place(
          id,
          placeData.title,
          placeData.description,
          placeData.imageUrl,
          placeData.price,
          new Date(placeData.availableFrom),
          new Date(placeData.availableTo),
          placeData.userId

          );
      })
    );
  }

  addPlace(
    title:string,
    description:string,
    price:number,
    dateFrom:Date,
    dateTo:Date
  )
  {
    let generatedId:string;
    let newPlace:Place;
    return this.authService.userId.pipe(take(1),switchMap(userId =>
    {
      if(!userId)
      {
        throw new Error('No user found!')
      }
      newPlace=new Place
      (
        Math.random().toString(),
        title,
        description,
        '',
        price,
        dateFrom,
        dateTo,
        userId
      );
      return this.http.post<{name:string}>('',
      {
        ...newPlace,
        id:null
      });
    }),switchMap(responseData =>
      {
        generatedId=responseData.name;
        return this.places //returns new observable by replacing the old one
      }),
      take(1),
      tap(places =>
        {
          newPlace.id=generatedId;
          this._places.next(places.concat(newPlace));
        })
      );
  }





  updateOffer(placeId:string,title:string,description:string)
  {
    let updatedPlaces:Place[];
    return this.places.pipe
    (
      take(1),
      switchMap(places =>
      {
        if(!places || places.length <=0)
        {
          return this.fetchPlaces();
        }
        else
        {
          return of(places);
        }
      }),
      switchMap(places => {
        const updatedPlaceIndex=places.findIndex(pl => pl.id===placeId);
        updatedPlaces=[...places];
        const oldPlace=updatedPlaces[updatedPlaceIndex];
        updatedPlaces[updatedPlaceIndex]=new Place
        (
          oldPlace.id,
          title,
          description,
          oldPlace.imageUrl,
          oldPlace.price,
          oldPlace.availableFrom,
          oldPlace.availableTo,
          oldPlace.userId
        );
        return this.http.put(
        ``,
        { ...updatedPlaces[updatedPlaceIndex],id:null}
        );}),tap(() =>  {
          this._places.next(updatedPlaces);
        })
    );


  }

}

