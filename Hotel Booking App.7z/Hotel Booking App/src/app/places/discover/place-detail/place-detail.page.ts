import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router} from '@angular/router';
import { Subscription } from 'rxjs';
import {switchMap, take} from 'rxjs/operators'
import {  ActionSheetController, AlertController, IonButtons, LoadingController, ModalController, NavController } from '@ionic/angular';
import { CreateBookingComponent } from '../../../bookings/create-booking/create-booking.component';
import { Place } from '../../place.model';
import { PlacesService } from '../../places.service';
import { BookingService } from '../../../bookings/booking.service';
import { AuthService } from 'src/app/auth/auth.service';

@Component({
  selector: 'app-place-detail',
  templateUrl: './place-detail.page.html',
  styleUrls: ['./place-detail.page.scss'],
})
export class PlaceDetailPage implements OnInit,OnDestroy {
  place:Place;
  isBookable=false;
  isLoading:boolean;
  private placeSub:Subscription;
  constructor(
    private placesService:PlacesService,
    private navCtrl:NavController,
    private modalController:ModalController,
    private route:ActivatedRoute,
    private actionSheetController:ActionSheetController,
    private bookingService:BookingService,
    private loadingController:LoadingController,
    private authService:AuthService,
    private alertController:AlertController,
    private router:Router
    ) { }
  ngOnDestroy() {
   if(this.placeSub)
   {
     this.placeSub.unsubscribe();
   }
  }



  ngOnInit() {
    let fetchedUserId:string;
    this.route.paramMap.subscribe(paramMap => {
      if (!paramMap.has('placeId')) {
        this.navCtrl.navigateBack('/places/tabs/discover');
        return;
      }
      this.isLoading=true;
      this.authService.userId.pipe(
        take(1),
        switchMap(userId =>{
        if(!userId){
          throw new Error('Found no user!');
        }
        fetchedUserId=userId;
        return this.placesService.getPlace(paramMap.get('placeId'));
      })).subscribe(place => {
       this.place=place;
       this.isBookable =place.userId !==fetchedUserId;
       this.isLoading=false;
     },
     error => {
      this.alertController.create({
        header:'An error has occured',
        message:'Could not load place',
        buttons:[{text:'okay',handler :() => {
          this.router.navigate(['places/tabs/discover'])
        }}]
      }

      ).then(actionSheetElement => actionSheetElement.present())
     }
     )//subscribe ends here
      console.log("Sharing data model",this.place)
    });

  }
  onBookPlace()
  {

    console.log("OnBookPlace()")
    //this.router.navigateByUrl('/places/tabs/discover')
    //this.navCtrl.navigateBack('/places/tabs/discover')
    this.actionSheetController.create({

      header:'Choose  an action',
      buttons:[
        {

          text:'Select Date', //Handler defines which code or function to run
          handler: () => {
            this.openBookingModal('select');
          }
        },

        {
          text:'Cancel',
          role:'destructive'  //Role 1>Destructive: will color the button red  attach your logic
                              //2>Cancel:Will be in the bottom most
        }
      ]
    })
    .then(actionSheetElement =>{
      actionSheetElement.present();

    })

    //this.navCtrl.pop();//pops from the stack of Pages but if no pages then wont work
  }

  openBookingModal(mode:'select'|'random') //mode has to be a string and exactly the same one
  {
    console.log(mode)
    this.modalController
    .create({
      component:CreateBookingComponent,
      componentProps:{selectedPlace:this.place,selectedMode:mode},

    })
    .then(modalEl =>{
      modalEl.present();
      return modalEl  .onDidDismiss();
    })
    .then(resultData =>{
      console.log(resultData.data,resultData.role);
      if(resultData.role==='confirm')
      {
        this.loadingController
        .create({message:'Booking Place...'})
        .then( loadingEl => {
          loadingEl.present();
          this.bookingService.addBooking(
            this.place.id,
            this.place.title,
            this.place.imageUrl,
            resultData.data.bookingData.firstName,
            resultData.data.bookingData.lastName,
            resultData.data.bookingData.guestNumber,
            resultData.data.bookingData.startDate,
            resultData.data.bookingData.endDate
          ).subscribe(() => {
            loadingEl.dismiss();
            this.router.navigateByUrl('/places/tabs/discover');
          })
        })

      }
    })

  }
}
