import { Component, OnDestroy, OnInit } from '@angular/core';
import { IonItemSliding, LoadingController } from '@ionic/angular';
import { Subscription } from 'rxjs';
import { Booking } from './booking.model';
import { BookingService } from './booking.service';

@Component({
  selector: 'app-bookings',
  templateUrl: './bookings.page.html',
  styleUrls: ['./bookings.page.scss'],
})
export class BookingsPage implements OnInit,OnDestroy {
  loadedBookings:Booking[];
  isLoading:boolean=false;
  private bookingSub:Subscription;
  constructor(
    private bookingService:BookingService,
    private loadingController:LoadingController
    ) { }

  ngOnInit() {
    this.bookingSub=this.bookingService.bookings.subscribe(bookings => {
      this.loadedBookings=bookings;
    })
  }

  ngOnDestroy(){
    if(this.bookingSub){
      this.bookingSub.unsubscribe();
    }
  }

  ionViewWillEnter()
  {
    this.isLoading=true;
    this.bookingService.fetchBookings().subscribe(() => {
      this.isLoading=false;
    });
  }

  onCancelBooking(bookingId:string,slidingElement:IonItemSliding)
  {
    slidingElement.close();
    this.loadingController.create({
      message:'Deleting Booking.....'
    }).then(loadingElement => {
      loadingElement.present();
      this.bookingService.cancelBooking(bookingId).subscribe(() => {
        loadingElement.dismiss();
      });
    })

    //cancel booking for offer id
  }

}
