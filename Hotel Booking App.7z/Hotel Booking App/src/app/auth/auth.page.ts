import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { AlertController, LoadingController } from '@ionic/angular';
import { Observable } from 'rxjs';
import { AuthResponseData, AuthService } from './auth.service';



@Component({
  selector: 'app-auth',
  templateUrl: './auth.page.html',
  styleUrls: ['./auth.page.scss'],
})
export class AuthPage implements OnInit {
  isLoading=false;
  isLogin=true;

  constructor(
    private authService:AuthService,
    private router:Router,
    private loadingCtrl:LoadingController,
    private alertController:AlertController

    ) { }

  ngOnInit() {
  }
  authenticate(email: string, password: string) {
    this.isLoading = true;
    this.loadingCtrl
      .create({ keyboardClose: true, message: 'Logging in...' })
      .then(loadingEl => {
        loadingEl.present();
        let authObs: Observable<AuthResponseData>;
        if (this.isLogin) {
          authObs = this.authService.login(email, password);
        } else {
          authObs = this.authService.signup(email, password);
        }
        authObs.subscribe(
          resData => {
            console.log("Response Data->"+resData[0]);
            this.isLoading = false;
            loadingEl.dismiss();
            console.log('loading Element dismissed')
            this.router.navigateByUrl('/places/tabs/discover');
          },
          errRes => {
            loadingEl.dismiss();
            this.isLoading=false
            console.log(errRes)
            const code = errRes.error.error.message;
            console.log(code);
            let message = code;
            if (code === 'EMAIL_EXISTS') {
              message = 'This email address exists already!';
            } else if (code === 'EMAIL_NOT_FOUND') {
              message = 'E-Mail address could not be found.';
            } else if (code === 'INVALID_PASSWORD') {
              message = 'This password is not correct.';
            }
            this.showAlert(message);
          }
        );
      });
  }
  onSubmit(form:NgForm)
  {
    console.log("****",form);
    if(!form.valid)
    {
      return;
    }
    const userEmail=form.value.email;
    const userPassword=form.value.password;

    console.log(userEmail,userPassword);
    this.authenticate(userEmail,userPassword)
    form.reset()
  }
  onSwitchAuthModel()
  {
    this.isLogin=!this.isLogin;
  }

  private showAlert(message:string)
  {
    this.alertController.create({
      header:'Authentication failed',
      message:message,
      buttons:['Okay']
    })
    .then(alertElement => alertElement.present());
  }
}
